<?php
$conn=mysqli_connect("sql100.infinityfree.com","if0_39969696","Likonda50","if0_39969696_cbe_student_portal");
if(!$conn){
    echo"databases error";
}

?>